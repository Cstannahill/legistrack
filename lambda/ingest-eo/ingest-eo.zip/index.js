// src/logger.ts
var LEVEL_RANK = {
  debug: 10,
  info: 20,
  warn: 30,
  error: 40
};
function shouldLog(level, minimum) {
  return LEVEL_RANK[level] >= LEVEL_RANK[minimum];
}
var Logger = class _Logger {
  context;
  minimumLevel;
  constructor(options = {}) {
    this.context = options.context;
    this.minimumLevel = options.minimumLevel ?? "info";
  }
  emit(entry) {
    const { level, message, context, timestamp, metadata } = entry;
    const base = {
      level,
      timestamp,
      context,
      message,
      ...metadata && Object.keys(metadata).length > 0 ? { metadata } : {}
    };
    switch (level) {
      case "debug":
        console.debug(base);
        break;
      case "info":
        console.info(base);
        break;
      case "warn":
        console.warn(base);
        break;
      case "error":
      default:
        console.error(base);
        break;
    }
  }
  log(level, message, metadata) {
    if (!shouldLog(level, this.minimumLevel)) {
      return;
    }
    this.emit({
      level,
      message,
      context: this.context,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      metadata
    });
  }
  debug(message, metadata) {
    this.log("debug", message, metadata);
  }
  info(message, metadata) {
    this.log("info", message, metadata);
  }
  warn(message, metadata) {
    this.log("warn", message, metadata);
  }
  error(message, metadata) {
    this.log("error", message, metadata);
  }
  child(context) {
    return new _Logger({
      context: this.context ? `${this.context}:${context}` : context,
      minimumLevel: this.minimumLevel
    });
  }
};
function createLogger(options = {}) {
  return new Logger(options);
}

// src/config.ts
var VALID_LOG_LEVELS = /* @__PURE__ */ new Set(["debug", "info", "warn", "error"]);
function parsePositiveInt(value, fallback) {
  if (!value) return fallback;
  const parsed = Number.parseInt(value, 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}
function parseBoolean(value, fallback) {
  if (value === void 0) return fallback;
  return ["true", "1", "yes", "y"].includes(value.toLowerCase());
}
function parseDocumentTypes(value) {
  if (!value) {
    return void 0;
  }
  const parsed = value.split(",").map((item) => item.trim().toLowerCase()).filter(Boolean);
  return parsed.length ? parsed : void 0;
}
function loadEnvironmentConfig() {
  const supabaseUrl = process.env.SUPABASE_URL;
  const supabaseServiceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY ?? process.env.SUPABASE_SERVICE_KEY;
  if (!supabaseUrl) {
    throw new Error("SUPABASE_URL must be configured for ingest-eo lambda");
  }
  if (!supabaseServiceRoleKey) {
    throw new Error(
      "SUPABASE_SERVICE_ROLE_KEY (or SUPABASE_SERVICE_KEY) must be configured for ingest-eo lambda"
    );
  }
  const lookbackDays = parsePositiveInt(
    process.env.EO_LOOKBACK_DAYS ?? process.env.INGEST_LOOKBACK_DAYS,
    14
  );
  const defaultPerPage = parsePositiveInt(
    process.env.EO_PER_PAGE ?? process.env.INGEST_EO_PER_PAGE,
    100
  );
  const defaultFetchFullText = parseBoolean(
    process.env.EO_FETCH_FULL_TEXT,
    true
  );
  const minimumLogLevel = process.env.MINIMUM_LOG_LEVEL ?? "info";
  if (!VALID_LOG_LEVELS.has(minimumLogLevel)) {
    throw new Error(
      `MINIMUM_LOG_LEVEL must be one of ${Array.from(VALID_LOG_LEVELS).join(", ")}`
    );
  }
  const defaultDocumentTypes = parseDocumentTypes(process.env.EO_DOCUMENT_TYPES) ?? parseDocumentTypes(process.env.INGEST_EO_DOCUMENT_TYPES);
  return {
    supabaseUrl,
    supabaseServiceRoleKey,
    lookbackDays,
    minimumLogLevel,
    defaultPerPage,
    defaultFetchFullText,
    defaultDocumentTypes
  };
}

// src/db.ts
import { createClient } from "@supabase/supabase-js";
var globalRef = globalThis;
function getSupabaseClient(config) {
  if (!globalRef.__eo_supabase) {
    const supabaseUrl = config?.supabaseUrl ?? process.env.SUPABASE_URL;
    const supabaseServiceRoleKey = config?.supabaseServiceRoleKey ?? process.env.SUPABASE_SERVICE_ROLE_KEY ?? process.env.SUPABASE_SERVICE_KEY;
    if (!supabaseUrl) {
      throw new Error("SUPABASE_URL must be configured");
    }
    if (!supabaseServiceRoleKey) {
      throw new Error(
        "SUPABASE_SERVICE_ROLE_KEY (or SUPABASE_SERVICE_KEY) must be configured"
      );
    }
    globalRef.__eo_supabase = createClient(
      supabaseUrl,
      supabaseServiceRoleKey,
      {
        auth: { persistSession: false }
      }
    );
  }
  return globalRef.__eo_supabase;
}

// src/federalRegisterApi.ts
var BASE_URL = "https://www.federalregister.gov/api/v1";
var DEFAULT_PER_PAGE = 100;
async function fetchExecutiveOrders(params = {}) {
  const { page = 1, perPage = DEFAULT_PER_PAGE, conditions = {} } = params;
  const url = new URL(`${BASE_URL}/documents.json`);
  url.searchParams.set("page", page.toString());
  url.searchParams.set("per_page", perPage.toString());
  url.searchParams.set("order", "newest");
  url.searchParams.append("conditions[type][]", "PRESDOCU");
  const documentTypes = conditions.presidentialDocumentType ?? (conditions.type?.length ? conditions.type : void 0);
  if (documentTypes?.length) {
    documentTypes.forEach(
      (type) => url.searchParams.append(
        "conditions[presidential_document_type][]",
        type.toLowerCase()
      )
    );
  }
  if (conditions.publicationDate?.gte) {
    url.searchParams.set(
      "conditions[publication_date][gte]",
      conditions.publicationDate.gte
    );
  }
  if (conditions.publicationDate?.lte) {
    url.searchParams.set(
      "conditions[publication_date][lte]",
      conditions.publicationDate.lte
    );
  }
  if (conditions.signingDate?.gte) {
    url.searchParams.set(
      "conditions[signing_date][gte]",
      conditions.signingDate.gte
    );
  }
  if (conditions.signingDate?.lte) {
    url.searchParams.set(
      "conditions[signing_date][lte]",
      conditions.signingDate.lte
    );
  }
  const response = await fetch(url.toString(), {
    headers: { Accept: "application/json" }
  });
  if (!response.ok) {
    const text = await response.text();
    throw new Error(
      `Federal Register API error: ${response.status} ${response.statusText} - ${text}`
    );
  }
  const data = await response.json();
  data.results = data.results ?? [];
  return data;
}
async function fetchExecutiveOrderDetails(documentNumber) {
  const response = await fetch(
    `${BASE_URL}/documents/${documentNumber}.json`,
    {
      headers: { Accept: "application/json" }
    }
  );
  if (!response.ok) {
    const text = await response.text();
    throw new Error(
      `Failed to fetch executive order detail ${documentNumber}: ${response.status} ${text}`
    );
  }
  return await response.json();
}
async function fetchExecutiveOrderFullText(documentNumber) {
  const url = `${BASE_URL}/documents/${documentNumber}.json?fields[]=full_text_xml_url&fields[]=body_html_url&fields[]=raw_text_url`;
  const response = await fetch(url, { headers: { Accept: "application/json" } });
  if (!response.ok) {
    return { content: null, url: null };
  }
  const data = await response.json();
  const candidateUrls = [
    data.body_html_url,
    data.raw_text_url,
    data.full_text_xml_url
  ].filter(Boolean);
  for (const candidate of candidateUrls) {
    try {
      const textResponse = await fetch(candidate);
      if (textResponse.ok) {
        const text = await textResponse.text();
        return { content: text, url: candidate };
      }
    } catch {
    }
  }
  return {
    content: null,
    url: candidateUrls[0] ?? null
  };
}

// src/utils.ts
function determineLookupWindow(lookbackDays, startDate, endDate) {
  const now = /* @__PURE__ */ new Date();
  const effectiveEnd = endDate ? new Date(endDate) : now;
  const effectiveStart = startDate ? new Date(startDate) : new Date(effectiveEnd.getTime() - Math.max(1, lookbackDays) * 864e5);
  if (Number.isNaN(effectiveStart.getTime())) {
    throw new Error(`Invalid start date provided: ${startDate}`);
  }
  if (Number.isNaN(effectiveEnd.getTime())) {
    throw new Error(`Invalid end date provided: ${endDate}`);
  }
  if (effectiveStart > effectiveEnd) {
    throw new Error(
      `Start date ${effectiveStart.toISOString()} cannot be after end date ${effectiveEnd.toISOString()}`
    );
  }
  return { from: effectiveStart, to: effectiveEnd };
}
function formatFederalRegisterDate(date) {
  return date.toISOString().split("T")[0];
}
function safeParseDate(input) {
  if (!input) return void 0;
  const parsed = new Date(input);
  return Number.isNaN(parsed.getTime()) ? void 0 : parsed;
}
function mapSubtypeToExecutiveOrderType(subtype) {
  const normalized = (subtype ?? "").toLowerCase().replace(/\s+/g, "_");
  switch (normalized) {
    case "presidential_memorandum":
      return "PRESIDENTIAL_MEMORANDUM";
    case "proclamation":
      return "PROCLAMATION";
    case "determination":
      return "DETERMINATION";
    case "executive_order":
    default:
      return "EXECUTIVE_ORDER";
  }
}
function extractOrderNumber(doc) {
  const tryNumber = (value) => {
    if (value === void 0 || value === null) return null;
    const parsed = typeof value === "string" ? Number.parseInt(value, 10) : Number(value);
    return Number.isNaN(parsed) ? null : parsed;
  };
  return tryNumber(doc.executive_order_number) ?? tryNumber(doc.presidential_document_number) ?? tryNumber(doc.proclamation_number) ?? extractFromTitle(doc.title) ?? null;
}
function extractFromTitle(title) {
  if (!title) return null;
  const match = title.match(/(?:Executive Order|EO)\s+(\d+)/i);
  return match ? Number.parseInt(match[1], 10) : null;
}
function ensureOrderNumber(doc, fallbackSeed) {
  const existing = extractOrderNumber(doc);
  if (existing) {
    return existing;
  }
  const seed = fallbackSeed ?? doc.document_number;
  let hash = 0;
  for (const char of seed) {
    hash = hash * 31 + char.charCodeAt(0) >>> 0;
  }
  return 1e5 + hash % 9e5;
}
function inferPresidentName(doc, signingDate) {
  if (doc.president?.name) {
    return doc.president.name;
  }
  const dateRef = signingDate ?? safeParseDate(doc.signing_date) ?? safeParseDate(doc.publication_date) ?? /* @__PURE__ */ new Date();
  const year = dateRef.getUTCFullYear();
  if (year >= 2025) return "Donald J. Trump";
  if (year >= 2021) return "Joseph R. Biden";
  if (year >= 2017) return "Donald J. Trump";
  if (year >= 2009) return "Barack Obama";
  if (year >= 2001) return "George W. Bush";
  if (year >= 1993) return "William J. Clinton";
  return "Unknown";
}
function buildExecutiveOrderIdentifier(doc) {
  return `${doc.document_number ?? "unknown"} - ${doc.title ?? "Untitled"}`;
}

// src/hydration.ts
async function hydrateExecutiveOrder(options) {
  const logger = options.logger ?? createLogger({ context: "hydrate-eo" });
  const baseDoc = options.document;
  const detail = await fetchExecutiveOrderDetails(baseDoc.document_number);
  const signingDate = safeParseDate(detail.signing_date) ?? safeParseDate(baseDoc.signing_date) ?? safeParseDate(detail.publication_date) ?? safeParseDate(baseDoc.publication_date);
  if (!signingDate) {
    throw new Error(
      `Missing signing date for document ${baseDoc.document_number}`
    );
  }
  const publicationDate = safeParseDate(detail.publication_date) ?? safeParseDate(baseDoc.publication_date);
  const orderNumber = ensureOrderNumber(detail, baseDoc.document_number);
  const executiveOrderType = mapSubtypeToExecutiveOrderType(
    detail.subtype ?? detail.presidential_document_type ?? baseDoc.subtype
  );
  const presidentName = inferPresidentName(detail, signingDate);
  let fullTextContent = null;
  let fullTextUrl = detail.body_html_url ?? detail.raw_text_url ?? detail.full_text_xml_url ?? baseDoc.body_html_url ?? baseDoc.raw_text_url ?? null;
  if (options.fetchFullText) {
    try {
      const { content, url } = await fetchExecutiveOrderFullText(
        detail.document_number
      );
      if (content) {
        fullTextContent = content;
      }
      if (url) {
        fullTextUrl = url;
      }
    } catch (error) {
      logger.warn("Failed to download executive order full text", {
        documentNumber: detail.document_number,
        error: error instanceof Error ? error.message : String(error)
      });
    }
  }
  return {
    documentNumber: detail.document_number,
    orderNumber,
    executiveOrderType,
    title: detail.title ?? baseDoc.title ?? "Untitled Executive Order",
    signingDate,
    publicationDate,
    federalRegisterUrl: detail.html_url ?? baseDoc.html_url,
    sourceUrl: detail.html_url ?? baseDoc.html_url,
    presidentName,
    summary: detail.abstract ?? baseDoc.abstract,
    fullText: fullTextContent,
    fullTextUrl
  };
}

// src/persistence.ts
import { randomUUID } from "crypto";
var PRESERVE_FIELDS = [
  "fullText",
  "fullTextUrl",
  "presidentName",
  "sourceUrl",
  "federalRegisterUrl"
];
function buildBaseData(data, fetchedAt) {
  return {
    orderNumber: data.orderNumber,
    executiveOrderType: data.executiveOrderType,
    title: data.title,
    signingDate: data.signingDate.toISOString(),
    publicationDate: data.publicationDate ? data.publicationDate.toISOString() : null,
    fullText: data.fullText ?? null,
    fullTextUrl: data.fullTextUrl ?? null,
    federalRegisterUrl: data.federalRegisterUrl ?? null,
    presidentName: data.presidentName ?? "Unknown",
    sourceUrl: data.sourceUrl ?? null,
    lastFetchedAt: fetchedAt,
    updatedAt: fetchedAt
  };
}
function mergeWithExisting(baseData, existing) {
  if (!existing) {
    return baseData;
  }
  const merged = { ...baseData };
  for (const field of PRESERVE_FIELDS) {
    const incoming = merged[field];
    if ((incoming === null || incoming === void 0 || typeof incoming === "string" && incoming.trim() === "") && existing[field] !== void 0 && existing[field] !== null) {
      merged[field] = existing[field];
    }
  }
  return merged;
}
async function persistExecutiveOrder(options) {
  const { supabase: supabase2, data } = options;
  const logger = options.logger ?? createLogger({ context: "eo-persist" });
  const identifier = `${data.orderNumber}-${data.title}`;
  try {
    const { data: existingData, error: existingError } = await supabase2.from("ExecutiveOrder").select(
      ["id", "fullText", "fullTextUrl", "presidentName", "sourceUrl", "federalRegisterUrl"].join(
        ","
      )
    ).eq("orderNumber", data.orderNumber).maybeSingle();
    if (existingError) {
      throw new Error(
        `Failed to lookup executive order ${identifier}: ${existingError.message}`
      );
    }
    const existing = existingData;
    const fetchedAt = (/* @__PURE__ */ new Date()).toISOString();
    const baseData = buildBaseData(data, fetchedAt);
    if (existing?.id) {
      const mergedData = mergeWithExisting(baseData, existing);
      const { data: updated, error: updateError } = await supabase2.from("ExecutiveOrder").update(mergedData).eq("id", existing.id).select("id").single();
      if (updateError) {
        throw new Error(
          `Failed to update executive order ${identifier}: ${updateError.message}`
        );
      }
      logger.info("Updated executive order", {
        identifier,
        executiveOrderId: updated.id
      });
      return { action: "updated", identifier, executiveOrderId: updated.id };
    }
    const newId = randomUUID();
    const { data: created, error: insertError } = await supabase2.from("ExecutiveOrder").insert([{ id: newId, ...baseData, createdAt: fetchedAt }]).select("id").single();
    if (insertError) {
      throw new Error(
        `Failed to create executive order ${identifier}: ${insertError.message}`
      );
    }
    logger.info("Created executive order", {
      identifier,
      executiveOrderId: created.id ?? newId
    });
    return {
      action: "created",
      identifier,
      executiveOrderId: created.id ?? newId
    };
  } catch (error) {
    logger.error("Failed to persist executive order", {
      identifier,
      error: error instanceof Error ? error.message : String(error)
    });
    return {
      action: "failed",
      identifier,
      message: error instanceof Error ? error.message : String(error)
    };
  }
}

// src/index.ts
var env = loadEnvironmentConfig();
var baseLogger = createLogger({
  context: "ingest-executive-orders",
  minimumLevel: env.minimumLogLevel
});
var supabase = getSupabaseClient({
  supabaseUrl: env.supabaseUrl,
  supabaseServiceRoleKey: env.supabaseServiceRoleKey
});
var delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
var handler = async (rawEvent) => {
  const event = rawEvent ?? {};
  const runId = Math.random().toString(36).slice(2, 10);
  const logger = baseLogger.child(`run:${runId}`);
  const lookbackDays = event.lookbackDays ?? env.lookbackDays;
  const window = determineLookupWindow(
    lookbackDays,
    event.startDate,
    event.endDate
  );
  const perPage = Math.min(event.perPage ?? env.defaultPerPage, 1e3);
  const fetchFullText = event.fetchFullText ?? env.defaultFetchFullText;
  const maxPages = event.maxPages ?? Number.POSITIVE_INFINITY;
  const documentTypes = event.documentTypes && event.documentTypes.length > 0 ? event.documentTypes : env.defaultDocumentTypes;
  logger.info("Starting executive order ingestion", {
    runId,
    windowStart: window.from.toISOString(),
    windowEnd: window.to.toISOString(),
    perPage,
    fetchFullText,
    documentTypes: documentTypes ?? "all"
  });
  const dateCondition = {
    gte: formatFederalRegisterDate(window.from),
    lte: formatFederalRegisterDate(window.to)
  };
  let page = 1;
  let processedPages = 0;
  const results = [];
  while (processedPages < maxPages) {
    const response = await fetchExecutiveOrders({
      page,
      perPage,
      conditions: {
        publicationDate: dateCondition,
        presidentialDocumentType: documentTypes
      }
    });
    const documents = response.results ?? [];
    logger.info("Fetched executive order page", {
      runId,
      page,
      count: documents.length,
      totalPages: response.total_pages
    });
    if (documents.length === 0) {
      break;
    }
    for (const document of documents) {
      const identifier = buildExecutiveOrderIdentifier(document);
      try {
        const hydrated = await hydrateExecutiveOrder({
          document,
          fetchFullText,
          logger
        });
        const result = await persistExecutiveOrder({
          supabase,
          data: hydrated,
          logger
        });
        results.push(result);
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        logger.error("Failed to process executive order", {
          identifier,
          message,
          runId
        });
        results.push({
          action: "failed",
          identifier,
          message
        });
      }
    }
    delay(1500);
    processedPages++;
    page++;
    if (page > response.total_pages) {
      break;
    }
  }
  const summary = {
    processed: results.length,
    created: results.filter((r) => r.action === "created").length,
    updated: results.filter((r) => r.action === "updated").length,
    skipped: results.filter((r) => r.action === "skipped").length,
    failed: results.filter((r) => r.action === "failed").length,
    windowStart: window.from.toISOString(),
    windowEnd: window.to.toISOString(),
    details: results.map((result) => ({
      identifier: result.identifier,
      action: result.action,
      message: result.message
    }))
  };
  logger.info("Executive order ingestion finished", {
    runId,
    summary
  });
  return summary;
};
export {
  handler
};
