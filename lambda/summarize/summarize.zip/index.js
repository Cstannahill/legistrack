// src/openrouter-models/gpt-oss-20b.json
var gpt_oss_20b_default = {
  id: "openai/gpt-oss-20b:free",
  canonical_slug: "openai/gpt-oss-20b",
  hugging_face_id: "openai/gpt-oss-20b",
  name: "OpenAI: gpt-oss-20b (free)",
  created: 1754414229,
  description: "gpt-oss-20b is an open-weight 21B parameter model released by OpenAI under the Apache 2.0 license. It uses a Mixture-of-Experts (MoE) architecture with 3.6B active parameters per forward pass, optimized for lower-latency inference and deployability on consumer or single-GPU hardware. The model is trained in OpenAI\u2019s Harmony response format and supports reasoning level configuration, fine-tuning, and agentic capabilities including function calling, tool use, and structured outputs.",
  context_length: 131072,
  architecture: {
    modality: "text->text",
    input_modalities: ["text"],
    output_modalities: ["text"],
    tokenizer: "GPT",
    instruct_type: null
  },
  pricing: {
    prompt: "0",
    completion: "0",
    request: "0",
    image: "0",
    web_search: "0",
    internal_reasoning: "0"
  },
  top_provider: {
    context_length: 131072,
    max_completion_tokens: 131072,
    is_moderated: false
  },
  per_request_limits: null,
  supported_parameters: [
    "frequency_penalty",
    "include_reasoning",
    "max_tokens",
    "presence_penalty",
    "reasoning",
    "repetition_penalty",
    "response_format",
    "seed",
    "stop",
    "structured_outputs",
    "temperature",
    "tool_choice",
    "tools",
    "top_k",
    "top_p"
  ],
  default_parameters: {
    temperature: null,
    top_p: null,
    frequency_penalty: null
  }
};

// src/openrouter-models/kat-coder-pro.json
var kat_coder_pro_default = {
  id: "kwaipilot/kat-coder-pro:free",
  canonical_slug: "kwaipilot/kat-coder-pro-v1",
  hugging_face_id: "",
  name: "Kwaipilot: Kat Coder (free)",
  created: 1762745912,
  description: "KAT-Coder is the flagship coding model from Kwaipilot. It achieves an exceptional 73.4% resolution rate on SWE-Bench Verified.\n\nKAT-Coder was trained using advanced multi-stage training including mid-training, supervised fine-tuning (SFT), reinforcement fine-tuning (RFT), and large-scale agentic reinforcement learning (RL) on enterprise codebases.",
  context_length: 256e3,
  architecture: {
    modality: "text->text",
    input_modalities: ["text"],
    output_modalities: ["text"],
    tokenizer: "Other",
    instruct_type: null
  },
  pricing: {
    prompt: "0",
    completion: "0",
    request: "0",
    image: "0",
    web_search: "0",
    internal_reasoning: "0"
  },
  top_provider: {
    context_length: 256e3,
    max_completion_tokens: 32e3,
    is_moderated: false
  },
  per_request_limits: null,
  supported_parameters: [
    "frequency_penalty",
    "max_tokens",
    "presence_penalty",
    "repetition_penalty",
    "response_format",
    "seed",
    "stop",
    "structured_outputs",
    "temperature",
    "tool_choice",
    "tools",
    "top_k",
    "top_p"
  ],
  default_parameters: {
    temperature: null,
    top_p: null,
    frequency_penalty: null
  }
};

// src/config.ts
var MODEL_REGISTRY = {
  "openai/gpt-oss-20b:free": gpt_oss_20b_default,
  "kwaipilot/kat-coder-pro:free": kat_coder_pro_default
};
function getEnvInt(name, fallback) {
  const raw = process.env[name];
  if (!raw) return fallback;
  const value = Number.parseInt(raw, 10);
  return Number.isFinite(value) && value > 0 ? value : fallback;
}
function getEnvIndex(name, fallback) {
  const raw = process.env[name];
  if (!raw) return fallback;
  const value = Number.parseInt(raw, 10);
  return Number.isFinite(value) && value >= 0 ? value : fallback;
}
function getModelKey(name, fallback) {
  const raw = process.env[name];
  if (!raw) return fallback;
  if (raw in MODEL_REGISTRY) {
    return raw;
  }
  console.warn(
    `[config] Unsupported OpenRouter model key '${raw}' for ${name}; falling back to ${fallback}`
  );
  return fallback;
}
function loadEnvironmentConfig() {
  const supabaseUrl = process.env.SUPABASE_URL;
  const supabaseServiceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY ?? process.env.SUPABASE_SERVICE_KEY;
  if (!supabaseUrl) {
    throw new Error("SUPABASE_URL must be configured for summarize lambda");
  }
  if (!supabaseServiceRoleKey) {
    throw new Error(
      "SUPABASE_SERVICE_ROLE_KEY (or SUPABASE_SERVICE_KEY) must be configured for summarize lambda"
    );
  }
  const billBatchSize = getEnvInt("OPENROUTER_BILL_BATCH_SIZE", getEnvInt("BILL_SUMMARY_BATCH_SIZE", 5));
  const executiveOrderBatchSize = getEnvInt("OPENROUTER_EO_BATCH_SIZE", getEnvInt("EO_SUMMARY_BATCH_SIZE", 5));
  const billModelKey = getModelKey("OPENROUTER_BILL_MODEL", "openai/gpt-oss-20b:free");
  const executiveOrderModelKey = getModelKey(
    "OPENROUTER_EO_MODEL",
    "kwaipilot/kat-coder-pro:free"
  );
  const siteUrl = process.env.SITE_URL || "https://legistrack.vercel.app";
  const appName = process.env.APP_NAME || "Legistrack Summarizer";
  return {
    supabaseUrl,
    supabaseServiceRoleKey,
    siteUrl,
    appName,
    billBatchSize,
    executiveOrderBatchSize,
    billModelKey,
    executiveOrderModelKey,
    billKeyIndex: getEnvIndex("OPENROUTER_BILL_KEY_INDEX", 0),
    executiveOrderKeyIndex: getEnvIndex("OPENROUTER_EO_KEY_INDEX", 1)
  };
}

// src/db.ts
import { createClient } from "@supabase/supabase-js";
var cachedClient;
function getSupabaseClient(config2) {
  if (!cachedClient) {
    cachedClient = createClient(config2.supabaseUrl, config2.supabaseServiceRoleKey, {
      auth: {
        persistSession: false
      }
    });
  }
  return cachedClient;
}

// src/prompts.ts
var BASE_SYSTEM_PROMPT = `You are a legislative research analyst. Summarize each item you receive and respond with ONLY valid JSON.
Return an array where each entry has:
{
  "id": string,
  "summary": string,
  "keyPoints": string[],
  "impactAreas": string[],
  "confidence": number (0-1)
}
Rules:
- Keep the same order as the input list.
- keyPoints should highlight the most important provisions (3-6 items).
- impactAreas should describe who or what is affected.
- Use professional, plain English.
- confidence should reflect how complete the provided text is.
- NEVER include any text before or after the JSON array.`;
function buildUserPrompt(items) {
  const shaped = items.map((item, index) => ({
    index: index + 1,
    id: item.sourceId,
    kind: item.kind,
    title: item.title,
    metadata: item.metadata,
    text: item.text
  }));
  return `You will receive ${items.length} document${items.length === 1 ? "" : "s"}. Each document must result in one summary object.
Documents:
${JSON.stringify(shaped, null, 2)}`;
}
function buildBatchPrompt(items) {
  return {
    systemPrompt: BASE_SYSTEM_PROMPT,
    userPrompt: buildUserPrompt(items)
  };
}

// src/keyManagement.ts
var OPENROUTER_KEYS = [
  process.env.OPENROUTER_KEY_1,
  process.env.OPENROUTER_KEY_2
].filter((value) => Boolean(value));
var keyCooldowns = {};
var roundRobinIndex = 0;
var nowMs = () => Date.now();
var sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
function maskKey(key) {
  if (!key) return "(unset)";
  return `${key.slice(0, 8)}\uFFFD${key.slice(-4)}`;
}
function normalizeIndex(index) {
  if (OPENROUTER_KEYS.length === 0) return 0;
  const normalized = index % OPENROUTER_KEYS.length;
  return normalized < 0 ? normalized + OPENROUTER_KEYS.length : normalized;
}
function keyReady(key) {
  return (keyCooldowns[key] ?? 0) <= nowMs();
}
function markKeyCooldown(key, waitMs) {
  if (!key) return;
  const until = nowMs() + Math.max(waitMs, 0);
  keyCooldowns[key] = Math.max(keyCooldowns[key] ?? 0, until);
  console.warn(
    `[openrouter] Cooling down key ${maskKey(key)} for ${(waitMs / 1e3).toFixed(1)}s`
  );
}
async function waitForNextWindow() {
  const nextAvailable = Math.min(
    ...OPENROUTER_KEYS.map((key) => keyCooldowns[key] ?? nowMs())
  );
  const delay = Math.max(0, nextAvailable - nowMs()) + 1e3;
  console.warn(`[openrouter] All keys on cooldown. Sleeping ${delay}ms`);
  await sleep(delay);
}
async function getApiKey(preferredIndex) {
  if (OPENROUTER_KEYS.length === 0) {
    throw new Error("No OpenRouter API keys configured");
  }
  const indices = [];
  if (preferredIndex !== void 0) {
    indices.push(normalizeIndex(preferredIndex));
  }
  for (let i = 0; i < OPENROUTER_KEYS.length; i++) {
    const idx = normalizeIndex(roundRobinIndex + i);
    if (!indices.includes(idx)) {
      indices.push(idx);
    }
  }
  for (const idx of indices) {
    const key = OPENROUTER_KEYS[idx];
    if (keyReady(key)) {
      roundRobinIndex = normalizeIndex(idx + 1);
      return key;
    }
  }
  await waitForNextWindow();
  return getApiKey(preferredIndex);
}

// src/openrouter.ts
var OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions";
var OpenRouterHttpError = class extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
  }
};
async function callOpenRouter(options) {
  const apiKey = await getApiKey(options.preferredKeyIndex);
  const model = MODEL_REGISTRY[options.modelKey];
  if (!model) {
    throw new Error(`Unknown OpenRouter model key '${options.modelKey}'`);
  }
  const maxTokens = Math.min(
    6e3,
    model.top_provider?.max_completion_tokens ?? 6e3
  );
  const payload = {
    model: model.id,
    temperature: Number(process.env.OPENROUTER_TEMPERATURE ?? "0.25"),
    max_tokens: maxTokens,
    top_p: 0.9,
    messages: [
      { role: "system", content: options.systemPrompt },
      { role: "user", content: options.userPrompt }
    ]
  };
  const response = await fetch(OPENROUTER_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
      "HTTP-Referer": options.config.siteUrl,
      "X-Title": options.config.appName
    },
    body: JSON.stringify(payload)
  });
  if (response.status === 429) {
    const retryAfter = Number(response.headers.get("retry-after")) * 1e3;
    markKeyCooldown(apiKey, Number.isFinite(retryAfter) ? retryAfter : 1e4);
    throw new OpenRouterHttpError("Rate limited by OpenRouter", 429);
  }
  if (!response.ok) {
    const text = await response.text();
    throw new OpenRouterHttpError(
      `OpenRouter request failed (${response.status}): ${text}`,
      response.status
    );
  }
  const data = await response.json();
  const choice = data?.choices?.[0];
  const content = choice?.message?.content;
  if (typeof content !== "string" || !content.trim()) {
    throw new Error("OpenRouter returned an empty response");
  }
  return {
    content,
    modelUsed: choice?.model ?? model.id,
    apiKeyMasked: maskKey(apiKey)
  };
}

// src/tokenLogger.ts
var TOKEN_CHAR_RATIO = 4;
function estimateTokens(text) {
  return Math.max(0, Math.ceil(text.length / TOKEN_CHAR_RATIO));
}
function logBatchTokenEstimate(options) {
  const userPrompt = options.buildUserPrompt(options.items);
  const batchTokens = estimateTokens(`${options.systemPrompt}
${userPrompt}`);
  const perItem = options.items.map((item) => {
    const promptForOne = options.buildUserPrompt([item]);
    return {
      id: item.sourceId,
      approxTokens: estimateTokens(`${options.systemPrompt}
${promptForOne}`)
    };
  });
  const report = {
    label: options.label,
    batchTokens,
    perItem
  };
  console.log(JSON.stringify({ tokenReport: report }));
  return report;
}

// src/summarizer.ts
async function summarizeItems({
  items,
  modelKey,
  preferredKeyIndex,
  config: config2,
  label
}) {
  if (!items.length) return [];
  const { systemPrompt, userPrompt } = buildBatchPrompt(items);
  logBatchTokenEstimate({
    label: `${label}-tokens`,
    systemPrompt,
    buildUserPrompt,
    items
  });
  const response = await callOpenRouter({
    systemPrompt,
    userPrompt,
    modelKey,
    preferredKeyIndex,
    config: config2,
    label
  });
  return parseModelResponse(response.content, response.modelUsed);
}
function parseModelResponse(raw, aiModel) {
  const jsonPayload = extractJsonArray(raw);
  const entries = JSON.parse(jsonPayload);
  if (!Array.isArray(entries)) {
    throw new Error("OpenRouter response is not a JSON array");
  }
  return entries.map((entry, index) => {
    const idCandidate = entry?.id ?? entry?.sourceId ?? entry?.identifier ?? index;
    const sourceId = String(idCandidate);
    const summaryText = normalizeText(entry?.summary ?? entry?.content ?? "");
    const keyPoints = normalizeStringArray(entry?.keyPoints ?? entry?.bullets);
    const impactAreas = normalizeStringArray(entry?.impactAreas ?? entry?.impacts);
    const confidence = normalizeConfidence(entry?.confidence);
    return {
      sourceId,
      summary: summaryText,
      keyPoints,
      impactAreas,
      confidence,
      aiModel
    };
  });
}
function extractJsonArray(text) {
  const start = text.indexOf("[");
  const end = text.lastIndexOf("]");
  if (start === -1 || end === -1 || end <= start) {
    throw new Error("Failed to locate JSON array in model response");
  }
  return text.slice(start, end + 1);
}
function normalizeText(value) {
  return typeof value === "string" ? value.trim() : "";
}
function normalizeStringArray(value) {
  if (Array.isArray(value)) {
    return value.map((item) => typeof item === "string" ? item.trim() : "").filter(Boolean);
  }
  if (typeof value === "string") {
    return value.split(/\n|,|;|\|/).map((item) => item.trim()).filter(Boolean);
  }
  return [];
}
function normalizeConfidence(value) {
  if (typeof value === "number" && Number.isFinite(value)) {
    return clamp(value, 0.1, 1);
  }
  if (typeof value === "string") {
    const parsed = Number.parseFloat(value);
    if (Number.isFinite(parsed)) {
      return clamp(parsed, 0.1, 1);
    }
  }
  return 0.75;
}
function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

// src/repositories/bills.ts
import { randomUUID } from "crypto";
var nowIso = () => (/* @__PURE__ */ new Date()).toISOString();
var BILL_FIELDS = `id, billType, billNumber, congress, title, shortTitle, currentStatus, statusDate, introducedDate, fullText, fullTextUrl`;
async function fetchBillsNeedingSummaries(client, limit) {
  if (limit <= 0) {
    return [];
  }
  const candidateCount = Math.max(limit * 3, limit);
  const { data, error } = await client.from("Bill").select(BILL_FIELDS).not("fullText", "is", null).order("introducedDate", { ascending: false }).limit(candidateCount);
  if (error) {
    throw new Error(`Failed to load bills: ${error.message}`);
  }
  const rows = data ?? [];
  const candidates = rows.filter(
    (bill) => typeof bill.fullText === "string" && bill.fullText.trim().length > 0
  );
  return filterBillsWithoutStandardSummary(client, candidates, limit);
}
async function filterBillsWithoutStandardSummary(client, candidates, limit) {
  const ids = candidates.map((bill) => bill.id);
  if (!ids.length) return [];
  const { data, error } = await client.from("Summary").select("billId").eq("summaryType", "STANDARD").in("billId", ids);
  if (error) {
    throw new Error(`Failed to load bill summaries: ${error.message}`);
  }
  const summaryRows = data ?? [];
  const summarizedIds = new Set(
    summaryRows.map((row) => row.billId).filter((value) => Boolean(value))
  );
  const unsummarized = candidates.filter((bill) => !summarizedIds.has(bill.id));
  return unsummarized.slice(0, limit);
}
async function persistBillSummary(client, result) {
  const { error } = await client.from("Summary").insert({
    id: randomUUID(),
    createdAt: nowIso(),
    updatedAt: nowIso(),
    billId: result.sourceId,
    summaryType: "STANDARD",
    content: result.summary,
    keyPoints: result.keyPoints,
    impactAreas: result.impactAreas,
    aiModel: result.aiModel,
    confidence: result.confidence
  });
  if (error) {
    throw new Error(`Failed to save bill summary: ${error.message}`);
  }
}

// src/repositories/executiveOrders.ts
import { randomUUID as randomUUID2 } from "crypto";
var nowIso2 = () => (/* @__PURE__ */ new Date()).toISOString();
var EO_FIELDS = `id, orderNumber, executiveOrderType, title, presidentName, signingDate, publicationDate, fullText, fullTextUrl`;
async function fetchExecutiveOrdersNeedingSummaries(client, limit) {
  if (limit <= 0) {
    return [];
  }
  const candidateCount = Math.max(limit * 3, limit);
  const { data, error } = await client.from("ExecutiveOrder").select(EO_FIELDS).not("fullText", "is", null).order("signingDate", { ascending: false }).limit(candidateCount);
  if (error) {
    throw new Error(`Failed to load executive orders: ${error.message}`);
  }
  const rows = data ?? [];
  const candidates = rows.filter(
    (eo) => typeof eo.fullText === "string" && eo.fullText.trim().length > 0
  );
  return filterExecutiveOrdersWithoutSummary(client, candidates, limit);
}
async function filterExecutiveOrdersWithoutSummary(client, candidates, limit) {
  const ids = candidates.map((eo) => eo.id);
  if (!ids.length) return [];
  const { data, error } = await client.from("Summary").select("executiveOrderId").eq("summaryType", "STANDARD").in("executiveOrderId", ids);
  if (error) {
    throw new Error(`Failed to load executive order summaries: ${error.message}`);
  }
  const summaryRows = data ?? [];
  const summarizedIds = new Set(
    summaryRows.map((row) => row.executiveOrderId).filter((value) => Boolean(value))
  );
  const unsummarized = candidates.filter((eo) => !summarizedIds.has(eo.id));
  return unsummarized.slice(0, limit);
}
async function persistExecutiveOrderSummary(client, result) {
  const { error } = await client.from("Summary").insert({
    id: randomUUID2(),
    createdAt: nowIso2(),
    updatedAt: nowIso2(),
    executiveOrderId: result.sourceId,
    summaryType: "STANDARD",
    content: result.summary,
    keyPoints: result.keyPoints,
    impactAreas: result.impactAreas,
    aiModel: result.aiModel,
    confidence: result.confidence
  });
  if (error) {
    throw new Error(`Failed to save executive order summary: ${error.message}`);
  }
}

// src/workflows.ts
function createMetrics() {
  return {
    requested: 0,
    prepared: 0,
    summarized: 0,
    persisted: 0,
    skipped: 0,
    failed: 0,
    errors: []
  };
}
async function processBillSummaries(client, config2) {
  const metrics = createMetrics();
  metrics.requested = config2.billBatchSize;
  const bills = await fetchBillsNeedingSummaries(client, config2.billBatchSize);
  metrics.prepared = bills.length;
  if (bills.length === 0) {
    console.info("[summarize:bills] No bills found that require summaries");
    return metrics;
  }
  const items = bills.map((bill) => mapBillToItem(bill));
  let summaries = [];
  try {
    summaries = await summarizeItems({
      items,
      modelKey: config2.billModelKey,
      preferredKeyIndex: config2.billKeyIndex,
      config: config2,
      label: "bill-batch"
    });
  } catch (error) {
    metrics.failed = bills.length;
    metrics.errors.push({
      id: "bill-batch",
      reason: error instanceof Error ? error.message : String(error)
    });
    console.error("[summarize:bills] Summarizer call failed", error);
    return metrics;
  }
  const summaryMap = new Map(summaries.map((item) => [item.sourceId, item]));
  for (const bill of items) {
    const summary = summaryMap.get(bill.sourceId);
    if (!summary || !summary.summary) {
      metrics.failed += 1;
      metrics.errors.push({
        id: bill.sourceId,
        reason: "Model response missing summary"
      });
      console.warn("[summarize:bills] Model returned no summary", bill.sourceId);
      continue;
    }
    try {
      await persistBillSummary(client, summary);
      metrics.summarized += 1;
      metrics.persisted += 1;
    } catch (error) {
      metrics.failed += 1;
      metrics.errors.push({
        id: bill.sourceId,
        reason: error instanceof Error ? error.message : String(error)
      });
      console.error("[summarize:bills] Failed to persist summary", {
        id: bill.sourceId,
        error
      });
    }
  }
  return metrics;
}
async function processExecutiveOrderSummaries(client, config2) {
  const metrics = createMetrics();
  metrics.requested = config2.executiveOrderBatchSize;
  const eos = await fetchExecutiveOrdersNeedingSummaries(
    client,
    config2.executiveOrderBatchSize
  );
  metrics.prepared = eos.length;
  if (eos.length === 0) {
    console.info("[summarize:eo] No executive orders found that require summaries");
    return metrics;
  }
  const items = eos.map((eo) => mapExecutiveOrderToItem(eo));
  let summaries = [];
  try {
    summaries = await summarizeItems({
      items,
      modelKey: config2.executiveOrderModelKey,
      preferredKeyIndex: config2.executiveOrderKeyIndex,
      config: config2,
      label: "eo-batch"
    });
  } catch (error) {
    metrics.failed = eos.length;
    metrics.errors.push({
      id: "eo-batch",
      reason: error instanceof Error ? error.message : String(error)
    });
    console.error("[summarize:eo] Summarizer call failed", error);
    return metrics;
  }
  const summaryMap = new Map(summaries.map((item) => [item.sourceId, item]));
  for (const item of items) {
    const summary = summaryMap.get(item.sourceId);
    if (!summary || !summary.summary) {
      metrics.failed += 1;
      metrics.errors.push({
        id: item.sourceId,
        reason: "Model response missing summary"
      });
      console.warn("[summarize:eo] Model returned no summary", item.sourceId);
      continue;
    }
    try {
      await persistExecutiveOrderSummary(client, summary);
      metrics.summarized += 1;
      metrics.persisted += 1;
    } catch (error) {
      metrics.failed += 1;
      metrics.errors.push({
        id: item.sourceId,
        reason: error instanceof Error ? error.message : String(error)
      });
      console.error("[summarize:eo] Failed to persist summary", {
        id: item.sourceId,
        error
      });
    }
  }
  return metrics;
}
function mapBillToItem(bill) {
  const fallbackTitle = `${bill.billType.toUpperCase()} ${bill.billNumber}`;
  return {
    sourceId: bill.id,
    kind: "bill",
    title: bill.title || bill.shortTitle || fallbackTitle,
    text: bill.fullText ?? "",
    metadata: {
      billType: bill.billType,
      billNumber: bill.billNumber,
      congress: bill.congress,
      currentStatus: bill.currentStatus,
      introducedDate: bill.introducedDate,
      statusDate: bill.statusDate
    }
  };
}
function mapExecutiveOrderToItem(eo) {
  return {
    sourceId: eo.id,
    kind: "executive_order",
    title: eo.title,
    text: eo.fullText ?? "",
    metadata: {
      orderNumber: eo.orderNumber,
      executiveOrderType: eo.executiveOrderType,
      presidentName: eo.presidentName,
      signingDate: eo.signingDate,
      publicationDate: eo.publicationDate
    }
  };
}

// src/index.ts
var config = loadEnvironmentConfig();
var supabase = getSupabaseClient(config);
var handler = async (event, context) => {
  const invocationMeta = {
    requestId: context?.awsRequestId,
    runId: Math.random().toString(36).slice(2, 10),
    eventSource: event && typeof event === "object" ? event.source : void 0
  };
  console.info("[summarize] Invocation start", invocationMeta);
  const bills = await processBillSummaries(supabase, config);
  if (bills.errors.length) {
    console.error("[summarize] Bill errors", bills.errors);
  }
  const executiveOrders = await processExecutiveOrderSummaries(supabase, config);
  if (executiveOrders.errors.length) {
    console.error("[summarize] Executive order errors", executiveOrders.errors);
  }
  const result = { bills, executiveOrders };
  console.info("[summarize] Invocation complete", result);
  return result;
};
export {
  handler
};
