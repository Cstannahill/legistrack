// src/logger.ts
var LEVEL_RANK = {
  debug: 10,
  info: 20,
  warn: 30,
  error: 40
};
function shouldLog(level, minimum) {
  return LEVEL_RANK[level] >= LEVEL_RANK[minimum];
}
var Logger = class _Logger {
  context;
  minimumLevel;
  constructor(options = {}) {
    this.context = options.context;
    this.minimumLevel = options.minimumLevel ?? "info";
  }
  emit(entry) {
    const { level, message, context, timestamp, metadata } = entry;
    const base = {
      level,
      timestamp,
      context,
      message,
      ...metadata && Object.keys(metadata).length > 0 ? { metadata } : {}
    };
    switch (level) {
      case "debug":
        console.debug(base);
        break;
      case "info":
        console.info(base);
        break;
      case "warn":
        console.warn(base);
        break;
      case "error":
      default:
        console.error(base);
        break;
    }
  }
  log(level, message, metadata) {
    if (!shouldLog(level, this.minimumLevel)) {
      return;
    }
    this.emit({
      level,
      message,
      context: this.context,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      metadata
    });
  }
  debug(message, metadata) {
    this.log("debug", message, metadata);
  }
  info(message, metadata) {
    this.log("info", message, metadata);
  }
  warn(message, metadata) {
    this.log("warn", message, metadata);
  }
  error(message, metadata) {
    this.log("error", message, metadata);
  }
  child(context) {
    return new _Logger({
      context: this.context ? `${this.context}:${context}` : context,
      minimumLevel: this.minimumLevel
    });
  }
};
function createLogger(options = {}) {
  return new Logger(options);
}

// src/constants.ts
var CONGRESS_API_BASE = "https://api.congress.gov/v3";
var CURRENT_CONGRESS = 119;
var daysInYear = 365.2425;
var maxTime = Math.pow(10, 8) * 24 * 60 * 60 * 1e3;
var minTime = -maxTime;
var secondsInHour = 3600;
var secondsInDay = secondsInHour * 24;
var secondsInWeek = secondsInDay * 7;
var secondsInYear = secondsInDay * daysInYear;
var secondsInMonth = secondsInYear / 12;
var secondsInQuarter = secondsInMonth * 3;
var constructFromSymbol = Symbol.for("constructDateFrom");

// src/config.ts
function loadEnvironmentConfig() {
  const CONGRESS_API_KEY = process.env.CONGRESS_API_KEY;
  const INGEST_LOOKBACK_DAYS = process.env.INGEST_LOOKBACK_DAYS;
  const MINIMUM_LOG_LEVEL = process.env.MINIMUM_LOG_LEVEL;
  const TARGET_CONGRESS = process.env.TARGET_CONGRESS;
  const SUPABASE_URL = process.env.SUPABASE_URL;
  const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY ?? process.env.SUPABASE_SERVICE_KEY;
  if (!CONGRESS_API_KEY) {
    throw new Error("CONGRESS_API_KEY is required to ingest legislation");
  }
  const lookbackDays = INGEST_LOOKBACK_DAYS ? Number.parseInt(INGEST_LOOKBACK_DAYS, 10) : 1;
  if (!Number.isFinite(lookbackDays) || lookbackDays <= 0) {
    throw new Error(
      `INGEST_LOOKBACK_DAYS must be a positive integer (received ${INGEST_LOOKBACK_DAYS})`
    );
  }
  const defaultCongress = TARGET_CONGRESS ? Number.parseInt(TARGET_CONGRESS, 10) : CURRENT_CONGRESS;
  if (!Number.isFinite(defaultCongress) || defaultCongress <= 0) {
    throw new Error(
      `TARGET_CONGRESS must be a positive integer (received ${TARGET_CONGRESS})`
    );
  }
  const minimumLogLevel = MINIMUM_LOG_LEVEL ?? "info";
  const validLevels = /* @__PURE__ */ new Set(["debug", "info", "warn", "error"]);
  if (!validLevels.has(minimumLogLevel)) {
    throw new Error(
      `MINIMUM_LOG_LEVEL must be one of debug, info, warn, or error (received ${MINIMUM_LOG_LEVEL})`
    );
  }
  if (!SUPABASE_URL) {
    throw new Error("SUPABASE_URL must be configured");
  }
  if (!SUPABASE_SERVICE_ROLE_KEY) {
    throw new Error(
      "SUPABASE_SERVICE_ROLE_KEY (or SUPABASE_SERVICE_KEY) must be configured"
    );
  }
  return {
    congressApiKey: CONGRESS_API_KEY,
    lookbackDays,
    defaultCongress,
    minimumLogLevel,
    supabaseUrl: SUPABASE_URL,
    supabaseServiceRoleKey: SUPABASE_SERVICE_ROLE_KEY
  };
}

// src/congressClient.ts
var DEFAULT_LIMIT = 250;
var TEXT_FORMAT_PRIORITY = [
  "FORMATTED TEXT",
  "TEXT",
  "TXT",
  "XML",
  "PDF",
  "HTML"
];
var CONGRESS_DOWNLOAD_BASE = "https://www.congress.gov";
function normalizeBillType(type) {
  return type.trim().toLowerCase();
}
function normalizeItems(input) {
  if (!input) return [];
  if (Array.isArray(input)) return input;
  const items = input.items;
  return Array.isArray(items) ? items : [];
}
function formatPriority(type) {
  if (!type) {
    return TEXT_FORMAT_PRIORITY.length + 1;
  }
  const normalized = type.toUpperCase();
  const index = TEXT_FORMAT_PRIORITY.findIndex(
    (entry) => normalized.includes(entry)
  );
  return index === -1 ? TEXT_FORMAT_PRIORITY.length : index;
}
function selectFormat(version) {
  if (!version) return void 0;
  const formats = normalizeItems(version.formats);
  if (formats.length === 0) {
    return void 0;
  }
  return formats.map((format) => ({ format, rank: formatPriority(format.type) })).sort((a, b) => a.rank - b.rank)[0]?.format;
}
function buildDownloadUrl(source, apiKey) {
  try {
    const url = source.startsWith("http") ? new URL(source) : new URL(source, CONGRESS_DOWNLOAD_BASE);
    if (!url.searchParams.has("api_key")) {
      url.searchParams.set("api_key", apiKey);
    }
    return url.toString();
  } catch {
    const separator = source.includes("?") ? "&" : "?";
    return `${source}${separator}api_key=${encodeURIComponent(apiKey)}`;
  }
}
var CongressClient = class {
  apiKey;
  logger;
  constructor(options) {
    this.apiKey = options.apiKey;
    this.logger = options.logger ?? createLogger({ context: "CongressClient" });
  }
  async fetchJson(path, params = {}) {
    const url = new URL(`${CONGRESS_API_BASE}${path}`);
    url.searchParams.set("api_key", this.apiKey);
    url.searchParams.set("format", "json");
    for (const [key, value] of Object.entries(params)) {
      url.searchParams.set(key, value);
    }
    this.logger.debug("Requesting Congress API", { url: url.toString() });
    const response = await fetch(url.toString(), {
      headers: { Accept: "application/json" }
    });
    if (!response.ok) {
      const body = await response.text();
      throw new Error(
        `Congress API request failed (${response.status} ${response.statusText}): ${body}`
      );
    }
    return await response.json();
  }
  async fetchBillPage(options) {
    const { congress, billTypes, limit, offset, fromDateTime, toDateTime } = options;
    const params = {
      limit: String(limit ?? DEFAULT_LIMIT),
      offset: String(offset ?? 0),
      fromDateTime,
      toDateTime
    };
    if (billTypes?.length) {
      params.billType = billTypes.map((type) => type.toLowerCase()).join(",");
    }
    return this.fetchJson(
      `/bill/${congress}`,
      params
    );
  }
  async fetchBillDetail(congress, billType, billNumber) {
    const normalizedType = normalizeBillType(billType);
    return this.fetchJson(
      `/bill/${congress}/${normalizedType}/${billNumber}`
    );
  }
  async fetchBillText(congress, billType, billNumber) {
    const normalizedType = normalizeBillType(billType);
    const response = await this.fetchJson(
      `/bill/${congress}/${normalizedType}/${billNumber}/text`
    );
    const versions = normalizeItems(response.textVersions);
    if (versions.length === 0) {
      return void 0;
    }
    const sorted = versions.sort((a, b) => {
      const aTime = a?.date ? Date.parse(a.date) : 0;
      const bTime = b?.date ? Date.parse(b.date) : 0;
      return bTime - aTime;
    });
    const preferredVersion = sorted.find((version) => selectFormat(version)) ?? sorted[0];
    const selectedFormat = selectFormat(preferredVersion);
    if (!selectedFormat?.url) {
      return {
        content: null,
        url: void 0,
        date: preferredVersion?.date
      };
    }
    const downloadUrl = buildDownloadUrl(selectedFormat.url, this.apiKey);
    try {
      const textResponse = await fetch(downloadUrl, {
        headers: { Accept: "text/plain, text/html;q=0.9, */*;q=0.1" }
      });
      if (textResponse.ok) {
        const raw = await textResponse.text();
        const content = raw.includes("<pre") ? raw.replace(/^.*?<pre[^>]*>/is, "").replace(/<\/pre>.*$/is, "").trim() : raw;
        return {
          content,
          url: downloadUrl,
          date: preferredVersion?.date
        };
      }
      this.logger.warn("Bill text download returned non-200", {
        billType,
        billNumber,
        status: textResponse.status,
        statusText: textResponse.statusText,
        url: downloadUrl
      });
    } catch (error) {
      this.logger.warn("Failed to download bill text", {
        error: error instanceof Error ? error.message : String(error),
        billType,
        billNumber,
        url: downloadUrl
      });
    }
    return {
      content: null,
      url: downloadUrl,
      date: preferredVersion?.date
    };
  }
  async fetchBillActions(congress, billType, billNumber) {
    const normalizedType = normalizeBillType(billType);
    return this.fetchJson(
      `/bill/${congress}/${normalizedType}/${billNumber}/actions`
    );
  }
  async fetchBillAmendments(congress, billType, billNumber) {
    const normalizedType = normalizeBillType(billType);
    return this.fetchJson(
      `/bill/${congress}/${normalizedType}/${billNumber}/amendments`
    );
  }
  async fetchBillCosponsors(congress, billType, billNumber) {
    const normalizedType = normalizeBillType(billType);
    const data = await this.fetchJson(`/bill/${congress}/${normalizedType}/${billNumber}/cosponsors`);
    return data.cosponsors?.items ?? [];
  }
  async fetchMember(bioguideId) {
    try {
      return await this.fetchJson(
        `/member/${bioguideId}`
      );
    } catch (error) {
      this.logger.warn("Failed to fetch member", {
        bioguideId,
        error: error instanceof Error ? error.message : String(error)
      });
      return null;
    }
  }
};

// src/constructFrom.js
function constructFrom(date, value) {
  if (typeof date === "function") return date(value);
  if (date && typeof date === "object" && constructFromSymbol in date)
    return date[constructFromSymbol](value);
  if (date instanceof Date) return new date.constructor(value);
  return new Date(value);
}

// src/toDate.js
function toDate(argument, context) {
  return constructFrom(context || argument, argument);
}

// src/addDays.js
function addDays(date, amount, options) {
  const _date = toDate(date, options?.in);
  if (isNaN(amount)) return constructFrom(options?.in || date, NaN);
  if (!amount) return _date;
  _date.setDate(_date.getDate() + amount);
  return _date;
}

// src/utils.ts
var STATUS_MAPPINGS = [
  { match: /became (public )?law/i, status: "BECAME_LAW" },
  { match: /vetoed/i, status: "VETOED" },
  {
    match: /presented to president|sent to president/i,
    status: "PRESENTED_TO_PRESIDENT"
  },
  { match: /passed senate|senate passed/i, status: "PASSED_SENATE" },
  { match: /passed house|house passed/i, status: "PASSED_HOUSE" },
  {
    match: /reported by committee|committee reported/i,
    status: "REPORTED_BY_COMMITTEE"
  },
  { match: /referred to|committee/i, status: "REFERRED_TO_COMMITTEE" },
  { match: /failed/i, status: "FAILED" }
];
function resolveStatus(bill, actions, fallbackDate) {
  const latestActionText = bill.latestAction?.text ?? actions[0]?.text ?? "";
  const resolved = STATUS_MAPPINGS.find(
    ({ match }) => match.test(latestActionText)
  );
  const status = resolved?.status ?? "INTRODUCED";
  const statusDateRaw = bill.latestAction?.actionDate ?? actions[0]?.actionDate;
  const parsedStatusDate = statusDateRaw ? new Date(statusDateRaw) : void 0;
  const statusDate = parsedStatusDate && !Number.isNaN(parsedStatusDate.getTime()) ? parsedStatusDate : fallbackDate;
  return { status, statusDate };
}
function determineLookupWindow(lookbackDays, startDate, endDate) {
  const now = /* @__PURE__ */ new Date();
  const effectiveEnd = endDate ? new Date(endDate) : now;
  const effectiveStart = startDate ? new Date(startDate) : addDays(effectiveEnd, -Math.max(lookbackDays, 1));
  if (Number.isNaN(effectiveStart.getTime())) {
    throw new Error(`Invalid start date provided: ${startDate}`);
  }
  if (Number.isNaN(effectiveEnd.getTime())) {
    throw new Error(`Invalid end date provided: ${endDate}`);
  }
  if (effectiveStart > effectiveEnd) {
    throw new Error(
      `Start date ${effectiveStart.toISOString()} cannot be after end date ${effectiveEnd.toISOString()}`
    );
  }
  return { from: effectiveStart, to: effectiveEnd };
}
function formatForCongressApi(date) {
  return date.toISOString().replace(/\.\d{3}Z$/, "Z");
}
function buildBillIdentifier(item) {
  const billType = "billType" in item ? item.billType ?? "" : item.type ?? "";
  const billNumber = "billNumber" in item ? item.billNumber ?? "" : item.number ?? "";
  const congress = item.congress ?? "?";
  return `${congress}-${String(billType).toUpperCase()}-${billNumber}`;
}
function normalizePersonName(person) {
  const firstName = person.firstName ?? person.fullName?.split(" ")[0] ?? "";
  const lastName = person.lastName ?? (person.fullName && person.fullName.includes(" ") ? person.fullName.split(" ").slice(-1)[0] : "");
  const fullName = person.fullName ?? `${firstName} ${lastName}`.trim();
  return { firstName, lastName, fullName };
}

// src/hydration.ts
async function hydrateBill(options) {
  const { client, bill, logger } = options;
  const scopedLogger = logger?.child("hydrate") ?? createLogger({ context: "hydrate" });
  const identifier = buildBillIdentifier(bill);
  scopedLogger.info("Hydrating bill", { identifier });
  const congress = bill.congress;
  const billType = bill.type;
  const billNumber = bill.number;
  const [detail, actionsResponse, amendmentsResponse, cosponsors] = await Promise.all([
    client.fetchBillDetail(congress, billType, billNumber),
    client.fetchBillActions(congress, billType, billNumber),
    client.fetchBillAmendments(congress, billType, billNumber),
    client.fetchBillCosponsors(congress, billType, billNumber)
  ]);
  let text;
  try {
    text = await client.fetchBillText(congress, billType, billNumber);
  } catch (error) {
    scopedLogger.warn("Failed to fetch bill text, will retry later", {
      identifier,
      error: error instanceof Error ? error.message : String(error)
    });
  }
  const actions = detail.bill.actions?.items ?? actionsResponse.actions ?? [];
  const amendments = amendmentsResponse.amendments ?? [];
  const cosponsorList = detail.bill.cosponsors?.items ?? cosponsors;
  scopedLogger.info("Hydration complete", {
    identifier,
    actions: actions.length,
    amendments: amendments.length,
    cosponsors: cosponsorList.length,
    hasText: Boolean(text?.content)
  });
  return {
    bill: detail.bill,
    text: text ?? void 0,
    actions,
    amendments,
    cosponsors: cosponsorList
  };
}

// src/persistence.ts
import { randomUUID } from "crypto";

// src/congressUrl.ts
var BILL_TYPE_URL_MAP = {
  hr: "house-bill",
  hres: "house-resolution",
  hjres: "house-joint-resolution",
  hconres: "house-concurrent-resolution",
  s: "senate-bill",
  sres: "senate-resolution",
  sjres: "senate-joint-resolution",
  sconres: "senate-concurrent-resolution"
};
function getCongressGovBillUrl(congress, billType, billNumber) {
  const normalizedType = billType.toLowerCase();
  const urlType = BILL_TYPE_URL_MAP[normalizedType];
  if (!urlType) {
    console.warn(`Unknown bill type: ${billType}`);
    return `https://www.congress.gov/bill/${congress}th-congress/${normalizedType}/${billNumber}`;
  }
  return `https://www.congress.gov/bill/${congress}th-congress/${urlType}/${billNumber}`;
}

// src/persistence.ts
var BILL_COSPONSOR_TABLE = "_Cosponsored";
var BILL_COLUMN = "A";
var MEMBER_COLUMN = "B";
function parseDate(value, fallback) {
  if (!value) {
    return fallback;
  }
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return fallback;
  }
  return date;
}
function deriveChamber(input) {
  if (!input) return void 0;
  const normalized = input.toLowerCase();
  if (["house", "h", "house of representatives"].includes(normalized)) {
    return "HOUSE";
  }
  if (["senate", "s"].includes(normalized)) {
    return "SENATE";
  }
  return void 0;
}
async function ensureMember(supabase2, reference, client, logger) {
  if (!reference?.bioguideId) {
    return void 0;
  }
  const { data: existing, error: lookupError } = await supabase2.from("Member").select("id").eq("bioguideId", reference.bioguideId).maybeSingle();
  if (lookupError) {
    throw new Error(
      `Failed to lookup member ${reference.bioguideId}: ${lookupError.message}`
    );
  }
  if (existing?.id) {
    return existing.id;
  }
  const detail = await client.fetchMember(reference.bioguideId);
  const member = detail?.member;
  const normalizedNames = normalizePersonName({
    firstName: member?.firstName ?? reference.firstName,
    lastName: member?.lastName ?? reference.lastName,
    fullName: member?.officialName ?? reference.fullName
  });
  const chamber = deriveChamber(member?.chamber?.code) ?? deriveChamber(member?.chamber?.name) ?? deriveChamber(reference.chamber ?? void 0) ?? deriveChamber(member?.terms?.[0]?.chamber);
  const term = member?.terms?.[0];
  const termStart = parseDate(term?.startDate) ?? (term?.startYear ? /* @__PURE__ */ new Date(`${term.startYear}-01-03T00:00:00Z`) : /* @__PURE__ */ new Date());
  const termEnd = parseDate(term?.endDate) ?? (term?.endYear ? /* @__PURE__ */ new Date(`${term.endYear}-01-03T00:00:00Z`) : void 0);
  const state = member?.state ?? term?.state ?? reference.state;
  const party = member?.party ?? term?.party ?? reference.party ?? "Unknown";
  const districtRaw = member?.district ?? term?.district ?? reference.district;
  const district = districtRaw ? Number.parseInt(String(districtRaw), 10) : null;
  if (!chamber || !state) {
    logger.warn("Unable to create member due to missing chamber or state", {
      bioguideId: reference.bioguideId,
      chamber,
      state
    });
    return void 0;
  }
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const insertPayload = {
    id: randomUUID(),
    bioguideId: reference.bioguideId,
    firstName: normalizedNames.firstName || "Unknown",
    lastName: normalizedNames.lastName || "Unknown",
    fullName: normalizedNames.fullName || `${normalizedNames.firstName} ${normalizedNames.lastName}`.trim(),
    chamber,
    state,
    party,
    district,
    termStart: termStart?.toISOString() ?? now,
    termEnd: termEnd ? termEnd.toISOString() : null,
    imageUrl: member?.depiction?.url ?? null,
    websiteUrl: member?.website ?? null,
    createdAt: now,
    updatedAt: now
  };
  const { data: created, error: insertError } = await supabase2.from("Member").insert(insertPayload).select("id").single();
  if (insertError) {
    if (insertError.code === "23505") {
      const { data: raced } = await supabase2.from("Member").select("id").eq("bioguideId", reference.bioguideId).maybeSingle();
      if (raced?.id) {
        logger.warn("Member already existed after race", {
          bioguideId: reference.bioguideId
        });
        return raced.id;
      }
    }
    throw new Error(
      `Failed to create member ${reference.bioguideId}: ${insertError.message}`
    );
  }
  logger.info("Created member", {
    bioguideId: reference.bioguideId,
    memberId: created.id
  });
  return created.id;
}
function buildBillData(data, billType, billNumber, sponsorId, fallbackIntroducedDate, status, statusDate, fetchedAt) {
  const sourceUrl = getCongressGovBillUrl(
    data.bill.congress ?? 0,
    billType,
    billNumber
  );
  return {
    billType,
    billNumber,
    congress: data.bill.congress ?? 0,
    title: data.bill.title ?? "",
    officialTitle: data.bill.title ?? null,
    shortTitle: data.bill.shortTitle ?? null,
    introducedDate: fallbackIntroducedDate.toISOString(),
    currentStatus: status,
    statusDate: statusDate.toISOString(),
    lawNumber: data.bill.laws?.[0]?.lawNumber ?? null,
    fullText: data.text?.content ?? null,
    fullTextUrl: data.text?.url ?? null,
    sponsorId: sponsorId ?? null,
    sourceUrl,
    lastFetchedAt: fetchedAt,
    updatedAt: fetchedAt
  };
}
var PRESERVE_WHEN_EMPTY_FIELDS = [
  "officialTitle",
  "shortTitle",
  "lawNumber",
  "fullText",
  "fullTextUrl",
  "sponsorId",
  "sourceUrl"
];
function mergeBillDataWithExisting(baseData, existing) {
  if (!existing) {
    return baseData;
  }
  const merged = { ...baseData };
  for (const field of PRESERVE_WHEN_EMPTY_FIELDS) {
    const nextValue = merged[field];
    if ((nextValue === null || nextValue === void 0 || typeof nextValue === "string" && nextValue.trim() === "") && existing[field] !== void 0 && existing[field] !== null) {
      merged[field] = existing[field];
    }
  }
  return merged;
}
function mapActionRecords(billId, actions, ingestedAt) {
  const records = [];
  for (const action of actions) {
    const actionDate = parseDate(action.actionDate);
    if (!actionDate) {
      continue;
    }
    const rawActionCode = action.sourceSystem?.code;
    const actionCode = rawActionCode === null || rawActionCode === void 0 ? null : String(rawActionCode);
    records.push({
      id: randomUUID(),
      billId,
      actionDate: actionDate.toISOString(),
      actionType: action.sourceSystem?.name ?? "Unknown",
      actionCode,
      text: action.text ?? "",
      createdAt: ingestedAt
    });
  }
  return records;
}
function mapAmendmentRecords(billId, amendments, sponsorLookup, ingestedAt) {
  return amendments.flatMap((amendment) => {
    const number = amendment.number;
    const type = amendment.type;
    const congress = amendment.congress;
    if (!number || !type || !congress) {
      return [];
    }
    const statusDate = parseDate(amendment.statusDate) ?? /* fall back to now */
    /* @__PURE__ */ new Date();
    const sponsorBioguide = amendment.sponsor?.bioguideId;
    const sponsorId = sponsorBioguide ? sponsorLookup.get(sponsorBioguide) : void 0;
    const isoStatusDate = statusDate.toISOString();
    const record = {
      id: randomUUID(),
      billId,
      amendmentNumber: number,
      amendmentType: type,
      congress,
      purpose: amendment.purpose ?? null,
      description: amendment.description ?? null,
      status: amendment.status ?? "Unknown",
      statusDate: isoStatusDate,
      sponsorId: sponsorId ?? null,
      proposedDate: isoStatusDate,
      sourceUrl: null,
      createdAt: ingestedAt,
      updatedAt: ingestedAt
    };
    return [record];
  });
}
async function replaceBillCosponsors(supabase2, billId, cosponsorIds) {
  const { error: deleteError } = await supabase2.from(BILL_COSPONSOR_TABLE).delete().eq(BILL_COLUMN, billId);
  if (deleteError) {
    throw new Error(
      `Failed to reset cosponsors for bill ${billId}: ${deleteError.message}`
    );
  }
  if (cosponsorIds.length === 0) {
    return;
  }
  const rows = cosponsorIds.map((memberId) => ({
    [BILL_COLUMN]: billId,
    [MEMBER_COLUMN]: memberId
  }));
  const { error: insertError } = await supabase2.from(BILL_COSPONSOR_TABLE).insert(rows);
  if (insertError) {
    throw new Error(
      `Failed to insert cosponsors for bill ${billId}: ${insertError.message}`
    );
  }
}
async function persistHydratedBill(options) {
  const { data, client, supabase: supabase2 } = options;
  const logger = options.logger ?? createLogger({ context: "persist" });
  const identifier = buildBillIdentifier(data.bill);
  try {
    const introducedDate = parseDate(data.bill.introducedDate) ?? new Date(data.bill.latestAction?.actionDate ?? Date.now());
    const fallbackIntroducedDate = introducedDate ?? /* @__PURE__ */ new Date();
    const { status, statusDate } = resolveStatus(
      data.bill,
      data.actions,
      fallbackIntroducedDate
    );
    const sponsorReference = data.bill.sponsor ?? data.bill.sponsors?.[0];
    const sponsorId = await ensureMember(
      supabase2,
      sponsorReference,
      client,
      logger.child("member")
    );
    const billTypeRaw = data.bill.billType ?? data.bill.type ?? "";
    const billType = billTypeRaw.toLowerCase();
    const billNumber = Number.parseInt(
      data.bill.billNumber ?? data.bill.number ?? "0",
      10
    );
    if (!billType || Number.isNaN(billNumber) || !data.bill.congress) {
      logger.warn("Skipping bill due to incomplete identifier", {
        identifier,
        billType,
        billNumber,
        congress: data.bill.congress
      });
      return {
        action: "skipped",
        identifier,
        message: "Missing bill type, number, or congress"
      };
    }
    const { data: existingData, error: existingError } = await supabase2.from("Bill").select(
      [
        "id",
        "officialTitle",
        "shortTitle",
        "lawNumber",
        "fullText",
        "fullTextUrl",
        "sponsorId",
        "sourceUrl"
      ].join(",")
    ).eq("congress", data.bill.congress ?? 0).eq("billType", billType).eq("billNumber", billNumber).maybeSingle();
    const existing = existingData;
    if (existingError) {
      throw new Error(
        `Failed to lookup bill ${identifier}: ${existingError.message}`
      );
    }
    const fetchedAt = (/* @__PURE__ */ new Date()).toISOString();
    const baseData = buildBillData(
      data,
      billType,
      billNumber,
      sponsorId,
      fallbackIntroducedDate,
      status,
      statusDate,
      fetchedAt
    );
    let billId;
    let action = "updated";
    if (existing?.id) {
      const mergedData = mergeBillDataWithExisting(baseData, existing);
      const { data: updated, error: updateError } = await supabase2.from("Bill").update(mergedData).eq("id", existing.id).select("id").single();
      if (updateError) {
        throw new Error(
          `Failed to update bill ${identifier}: ${updateError.message}`
        );
      }
      billId = updated.id;
    } else {
      const newBillId = randomUUID();
      const { data: created, error: insertError } = await supabase2.from("Bill").insert({ id: newBillId, ...baseData, createdAt: fetchedAt }).select("id").single();
      if (insertError) {
        throw new Error(
          `Failed to create bill ${identifier}: ${insertError.message}`
        );
      }
      billId = created.id ?? newBillId;
      action = "created";
    }
    const cosponsorIds = [];
    const sponsorLookup = /* @__PURE__ */ new Map();
    if (sponsorReference?.bioguideId && sponsorId) {
      sponsorLookup.set(sponsorReference.bioguideId, sponsorId);
    }
    for (const cosponsor of data.cosponsors) {
      const id = await ensureMember(
        supabase2,
        cosponsor,
        client,
        logger.child("cosponsor")
      );
      if (id) {
        cosponsorIds.push(id);
        if (cosponsor.bioguideId) {
          sponsorLookup.set(cosponsor.bioguideId, id);
        }
      }
    }
    await replaceBillCosponsors(supabase2, billId, cosponsorIds);
    const actionRecords = mapActionRecords(billId, data.actions, fetchedAt);
    const { error: deleteActionsError } = await supabase2.from("Action").delete().eq("billId", billId);
    if (deleteActionsError) {
      throw new Error(
        `Failed to delete prior actions for ${identifier}: ${deleteActionsError.message}`
      );
    }
    if (actionRecords.length > 0) {
      const { error: insertActionsError } = await supabase2.from("Action").insert(actionRecords);
      if (insertActionsError) {
        throw new Error(
          `Failed to insert actions for ${identifier}: ${insertActionsError.message}`
        );
      }
    }
    const amendmentRecords = mapAmendmentRecords(
      billId,
      data.amendments,
      sponsorLookup,
      fetchedAt
    );
    const { error: deleteAmendmentsError } = await supabase2.from("Amendment").delete().eq("billId", billId);
    if (deleteAmendmentsError) {
      throw new Error(
        `Failed to delete prior amendments for ${identifier}: ${deleteAmendmentsError.message}`
      );
    }
    if (amendmentRecords.length > 0) {
      const { error: insertAmendmentsError } = await supabase2.from("Amendment").insert(amendmentRecords);
      if (insertAmendmentsError) {
        throw new Error(
          `Failed to insert amendments for ${identifier}: ${insertAmendmentsError.message}`
        );
      }
    }
    logger.info("Persisted bill", {
      identifier,
      billId,
      action,
      actions: actionRecords.length,
      amendments: amendmentRecords.length,
      cosponsors: cosponsorIds.length
    });
    return { action, billId, identifier };
  } catch (error) {
    logger.error("Failed to persist bill", {
      identifier,
      error: error instanceof Error ? error.message : String(error)
    });
    return {
      action: "failed",
      identifier,
      message: error instanceof Error ? error.message : String(error)
    };
  }
}

// src/db.ts
import { createClient } from "@supabase/supabase-js";
var globalForSupabase = globalThis;
function getSupabaseClient(config) {
  if (!globalForSupabase.__supabase) {
    const supabaseUrl = config?.supabaseUrl ?? process.env.SUPABASE_URL;
    const supabaseServiceRoleKey = config?.supabaseServiceRoleKey ?? process.env.SUPABASE_SERVICE_ROLE_KEY ?? process.env.SUPABASE_SERVICE_KEY;
    if (!supabaseUrl) {
      throw new Error("SUPABASE_URL must be configured");
    }
    if (!supabaseServiceRoleKey) {
      throw new Error(
        "SUPABASE_SERVICE_ROLE_KEY (or SUPABASE_SERVICE_KEY) must be configured"
      );
    }
    globalForSupabase.__supabase = createClient(
      supabaseUrl,
      supabaseServiceRoleKey,
      {
        auth: {
          persistSession: false
        }
      }
    );
  }
  return globalForSupabase.__supabase;
}

// src/index.ts
var env = loadEnvironmentConfig();
var baseLogger = createLogger({
  context: "ingest-legislation",
  minimumLevel: env.minimumLogLevel
});
var supabase = getSupabaseClient({
  supabaseUrl: env.supabaseUrl,
  supabaseServiceRoleKey: env.supabaseServiceRoleKey
});
var congressClient = new CongressClient({
  apiKey: env.congressApiKey,
  logger: baseLogger.child("congress")
});
var delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
var handler = async (event = {}) => {
  const runId = Math.random().toString(36).slice(2, 10);
  const logger = baseLogger.child(`run:${runId}`);
  const lookbackDays = event?.lookbackDays ?? env.lookbackDays;
  const targetCongress = event?.congress ?? env.defaultCongress;
  const window = determineLookupWindow(
    lookbackDays,
    event.startDate,
    event.endDate
  );
  logger.info("Starting legislation ingestion", {
    runId,
    start: window.from.toISOString(),
    end: window.to.toISOString(),
    congress: targetCongress,
    billTypes: event.billTypes,
    limit: event.limit
  });
  const limit = event.limit ?? 100;
  let offset = 0;
  const results = [];
  while (true) {
    const page = await congressClient.fetchBillPage({
      congress: targetCongress,
      billTypes: event.billTypes,
      limit,
      offset,
      fromDateTime: formatForCongressApi(window.from),
      toDateTime: formatForCongressApi(window.to)
    });
    const bills = page.bills ?? [];
    logger.info("Fetched bill page", {
      runId,
      count: bills.length,
      offset
    });
    if (bills.length === 0) {
      break;
    }
    for (const bill of bills) {
      const identifier = buildBillIdentifier(bill);
      try {
        const hydrated = await hydrateBill({
          client: congressClient,
          bill,
          logger
        });
        const result = await persistHydratedBill({
          data: hydrated,
          client: congressClient,
          supabase,
          logger
        });
        results.push(result);
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        logger.error("Failed to ingest bill", { identifier, message, runId });
        results.push({
          action: "failed",
          identifier,
          message
        });
      }
    }
    offset += bills.length;
    await delay(1250);
    const nextUrl = page.pagination?.next;
    if (!nextUrl || bills.length < limit) {
      break;
    }
  }
  const summary = {
    processed: results.length,
    created: results.filter((r) => r.action === "created").length,
    updated: results.filter((r) => r.action === "updated").length,
    skipped: results.filter((r) => r.action === "skipped").length,
    failed: results.filter((r) => r.action === "failed").length,
    windowStart: window.from.toISOString(),
    windowEnd: window.to.toISOString(),
    details: results.map((result) => ({
      identifier: result.identifier,
      action: result.action,
      message: result.message
    }))
  };
  logger.info("Legislation ingestion finished", { runId, summary });
  return summary;
};
export {
  handler
};
