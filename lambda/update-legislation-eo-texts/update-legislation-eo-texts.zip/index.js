// src/config.ts
function parsePositiveInt(value, fallback) {
  if (!value) return fallback;
  const parsed = Number.parseInt(value, 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : fallback;
}
function resolveInt(names, fallback) {
  for (const name of names) {
    const raw = process.env[name];
    if (raw) {
      return parsePositiveInt(raw, fallback);
    }
  }
  return fallback;
}
function loadEnvironmentConfig() {
  const supabaseUrl = process.env.SUPABASE_URL;
  const supabaseServiceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY ?? process.env.SUPABASE_SERVICE_KEY;
  if (!supabaseUrl) {
    throw new Error("SUPABASE_URL must be configured for update-legislation-eo-texts lambda");
  }
  if (!supabaseServiceRoleKey) {
    throw new Error(
      "SUPABASE_SERVICE_ROLE_KEY (or SUPABASE_SERVICE_KEY) must be configured for update-legislation-eo-texts lambda"
    );
  }
  const billBatchSize = resolveInt(
    ["BILL_TEXT_BATCH_SIZE", "BILL_BATCH_SIZE"],
    5
  );
  const executiveOrderBatchSize = resolveInt(
    ["EO_TEXT_BATCH_SIZE", "EO_BATCH_SIZE"],
    5
  );
  const billDelayMs = resolveInt(["BILL_TEXT_DELAY_MS"], 500);
  const executiveOrderDelayMs = resolveInt(["EO_TEXT_DELAY_MS"], 1e3);
  return {
    supabaseUrl,
    supabaseServiceRoleKey,
    billBatchSize,
    executiveOrderBatchSize,
    billDelayMs,
    executiveOrderDelayMs
  };
}

// src/db.ts
import { createClient } from "@supabase/supabase-js";
var cachedClient;
function getSupabaseClient(config2) {
  if (!cachedClient) {
    cachedClient = createClient(
      config2.supabaseUrl,
      config2.supabaseServiceRoleKey,
      {
        auth: {
          persistSession: false
        }
      }
    );
  }
  return cachedClient;
}

// src/lib/congress.ts
var getCongressAPIKey = () => process.env.CONGRESS_API_KEY;
var BASE_URL = "https://api.congress.gov/v3";
async function fetchBillText(congress, billType, billNumber) {
  const url = `${BASE_URL}/bill/${congress}/${billType}/${billNumber}/text`;
  const response = await fetch(
    `${url}?api_key=${getCongressAPIKey()}&format=json`,
    {
      headers: { Accept: "application/json" }
    }
  );
  if (!response.ok) {
    return null;
  }
  const data = await response.json();
  const textVersions = data.textVersions || [];
  if (textVersions.length === 0) {
    return null;
  }
  const latestVersion = textVersions[0];
  const formattedText = latestVersion.formats?.find(
    (f) => f.type === "Formatted Text" || f.type === "TXT"
  );
  if (formattedText?.url) {
    try {
      const textResponse = await fetch(
        `${formattedText.url}?api_key=${getCongressAPIKey()}`,
        {
          headers: { Accept: "text/html,text/plain,*/*" }
        }
      );
      if (textResponse.ok) {
        let fullText = await textResponse.text();
        if (fullText.includes("<html>") && fullText.includes("<pre>")) {
          const preMatch = fullText.match(/<pre>([\s\S]*?)<\/pre>/i);
          if (preMatch) {
            fullText = preMatch[1].trim();
          }
        }
        return {
          text: fullText,
          url: formattedText.url,
          date: latestVersion.date
        };
      }
    } catch (error) {
      console.error("Error fetching full text content:", error);
    }
  }
  return {
    text: null,
    url: formattedText?.url || latestVersion.formats?.[0]?.url,
    date: latestVersion.date
  };
}

// src/lib/federal-register.ts
var BASE_URL2 = "https://www.federalregister.gov/api/v1";
async function fetchExecutiveOrderFullText(documentNumber) {
  const url = `${BASE_URL2}/documents/${documentNumber}.json?fields[]=full_text_xml_url&fields[]=body_html_url&fields[]=raw_text_url`;
  const response = await fetch(url, {
    headers: { Accept: "application/json" }
  });
  if (!response.ok) {
    return null;
  }
  const data = await response.json();
  if (data.body_html_url) {
    const textResponse = await fetch(data.body_html_url);
    if (textResponse.ok) {
      return await textResponse.text();
    }
  }
  if (data.raw_text_url) {
    const textResponse = await fetch(data.raw_text_url);
    if (textResponse.ok) {
      return await textResponse.text();
    }
  }
  return null;
}

// src/repositories/bills.ts
var BILL_FIELDS = `id, billType, billNumber, congress, title, fullText, fullTextUrl`;
async function fetchBillsWithoutFullText(client, limit) {
  if (limit <= 0) return [];
  const { data, error } = await client.from("Bill").select(BILL_FIELDS).is("fullText", null).order("introducedDate", { ascending: false }).limit(limit);
  if (error) {
    throw new Error(`Failed to load bills without full text: ${error.message}`);
  }
  return data ?? [];
}
async function updateBillWithFullText(client, billId, text, url) {
  const { error } = await client.from("Bill").update({ fullText: text, fullTextUrl: url ?? null }).eq("id", billId);
  if (error) {
    throw new Error(`Failed to update bill ${billId} with full text: ${error.message}`);
  }
}
async function updateBillWithTextUrl(client, billId, url) {
  const { error } = await client.from("Bill").update({ fullTextUrl: url }).eq("id", billId);
  if (error) {
    throw new Error(`Failed to update bill ${billId} with text URL: ${error.message}`);
  }
}

// src/repositories/executiveOrders.ts
var EO_FIELDS = `id, orderNumber, title, signingDate, fullText, federalRegisterUrl`;
async function fetchExecutiveOrdersWithoutFullText(client, limit) {
  if (limit <= 0) return [];
  const { data, error } = await client.from("ExecutiveOrder").select(EO_FIELDS).is("fullText", null).order("signingDate", { ascending: false }).limit(limit);
  if (error) {
    throw new Error(`Failed to load executive orders without full text: ${error.message}`);
  }
  return data ?? [];
}
async function updateExecutiveOrderText(client, eoId, text) {
  const { error } = await client.from("ExecutiveOrder").update({ fullText: text }).eq("id", eoId);
  if (error) {
    throw new Error(`Failed to update executive order ${eoId}: ${error.message}`);
  }
}

// src/workflows.ts
var delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
async function updateBillTexts(client, config2) {
  const requested = config2.billBatchSize;
  const bills = await fetchBillsWithoutFullText(client, requested);
  if (bills.length === 0) {
    console.info("[update-texts:bills] All bills already have full text");
    return createSummary(requested, 0, 0, 0, 0);
  }
  console.info(
    `[update-texts:bills] Found ${bills.length} bills missing full text`
  );
  const result = createSummary(requested, bills.length, 0, 0, 0);
  for (let i = 0; i < bills.length; i++) {
    const bill = bills[i];
    await handleBill(client, bill, result);
    if (i < bills.length - 1) {
      await delay(config2.billDelayMs);
    }
  }
  logBillSummary(result);
  return result;
}
async function updateExecutiveOrderTexts(client, config2) {
  const requested = config2.executiveOrderBatchSize;
  const eos = await fetchExecutiveOrdersWithoutFullText(client, requested);
  if (eos.length === 0) {
    console.info("[update-texts:eo] All executive orders already have full text");
    return createSummary(requested, 0, 0, 0, 0);
  }
  console.info(
    `[update-texts:eo] Found ${eos.length} executive orders missing full text`
  );
  const result = createSummary(requested, eos.length, 0, 0, 0);
  for (let i = 0; i < eos.length; i++) {
    const eo = eos[i];
    await handleExecutiveOrder(client, eo, result);
    if (i < eos.length - 1) {
      await delay(config2.executiveOrderDelayMs);
    }
  }
  logExecutiveSummary(result);
  return result;
}
async function handleBill(client, bill, summary) {
  const identifier = `${bill.billType.toUpperCase()} ${bill.billNumber}`;
  console.log(`
[bill] Processing ${identifier}`);
  try {
    const textData = await fetchBillText(
      bill.congress,
      bill.billType,
      bill.billNumber
    );
    if (textData?.text) {
      await updateBillWithFullText(client, bill.id, textData.text, textData.url);
      summary.updated += 1;
      console.log(
        `   ? Saved full text (${textData.text.length} chars) for ${bill.title}`
      );
    } else if (textData?.url) {
      await updateBillWithTextUrl(client, bill.id, textData.url);
      summary.urlOnly += 1;
      console.log(
        `   ?? Text not available yet, stored source URL for ${bill.title}`
      );
    } else {
      summary.failed += 1;
      console.warn(`   ?? No text available for ${bill.title}`);
    }
  } catch (error) {
    summary.failed += 1;
    console.error(
      `   ? Failed to fetch bill text for ${identifier}:`,
      error instanceof Error ? error.message : String(error)
    );
  }
}
async function handleExecutiveOrder(client, eo, summary) {
  const identifier = `EO ${eo.orderNumber}`;
  console.log(`
[eo] Processing ${identifier}`);
  const documentNumber = extractDocumentNumber(eo.federalRegisterUrl ?? "");
  if (!documentNumber) {
    summary.failed += 1;
    console.warn(`   ?? Could not extract document number for ${identifier}`);
    return;
  }
  console.log(`   Federal Register document: ${documentNumber}`);
  try {
    const fullText = await fetchExecutiveOrderFullText(documentNumber);
    if (!fullText) {
      summary.failed += 1;
      console.warn(`   ?? No text available for ${identifier}`);
      return;
    }
    await updateExecutiveOrderText(client, eo.id, fullText);
    summary.updated += 1;
    console.log(
      `   ? Saved ${(fullText.length / 1024).toFixed(1)}KB of text for ${identifier}`
    );
  } catch (error) {
    summary.failed += 1;
    console.error(
      `   ? Failed to fetch EO text for ${identifier}:`,
      error instanceof Error ? error.message : String(error)
    );
  }
}
function extractDocumentNumber(url) {
  const match = url.match(/\/documents\/\d{4}\/\d{2}\/\d{2}\/([^/?#]+)/i);
  return match?.[1];
}
function createSummary(requested, processed, updated, urlOnly, failed) {
  return { requested, processed, updated, urlOnly, failed };
}
function logBillSummary(summary) {
  console.log("\n[bill] Summary");
  console.log(`   ? Full text fetched: ${summary.updated}`);
  console.log(`   ?? URLs saved: ${summary.urlOnly}`);
  console.log(`   ? Failed: ${summary.failed}`);
  console.log(`   ?? Total processed: ${summary.processed}`);
}
function logExecutiveSummary(summary) {
  console.log("\n[eo] Summary");
  console.log(`   ? Full text fetched: ${summary.updated}`);
  console.log(`   ? Failed: ${summary.failed}`);
  console.log(`   ?? Total processed: ${summary.processed}`);
}

// src/index.ts
var config = loadEnvironmentConfig();
var supabase = getSupabaseClient(config);
var handler = async () => {
  console.info("[update-texts] Invocation start", {
    billBatchSize: config.billBatchSize,
    executiveOrderBatchSize: config.executiveOrderBatchSize
  });
  const bills = await updateBillTexts(supabase, config);
  const executiveOrders = await updateExecutiveOrderTexts(supabase, config);
  const result = { bills, executiveOrders };
  console.info("[update-texts] Invocation complete", result);
  return result;
};
export {
  handler
};
